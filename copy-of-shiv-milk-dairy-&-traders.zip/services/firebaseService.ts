import { UserStats, Seller } from '../types';

// NOTE: In a real environment, you would import these from firebase/app, firebase/auth, firebase/firestore
// and initialize with process.env keys.
// For this runnable demo, we simulate the async behavior of Firebase.

const MOCK_DELAY = 800;

export const mockUserStats: UserStats = {
  memberId: "SMD-2024-001",
  name: "Rajesh Kumar",
  totalQuantity: 450.5,
  totalEarnings: 22525,
  lastCollectionDate: new Date().toLocaleDateString('en-IN')
};

export const mockBestSeller: Seller = {
  id: "farm-88",
  name: "Suresh Yadav",
  totalQuantity: 1240
};

export const authService = {
  login: async (): Promise<{ uid: string; email: string }> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ uid: "user_123", email: "member@shivdairy.com" });
      }, MOCK_DELAY);
    });
  },
  logout: async (): Promise<void> => {
    return new Promise((resolve) => {
      setTimeout(() => resolve(), MOCK_DELAY / 2);
    });
  }
};

export const dbService = {
  getUserStats: async (userId: string): Promise<UserStats> => {
    console.log(`Fetching stats for ${userId} from artifacts/{appId}/users/${userId}/milk_stats/data`);
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(mockUserStats);
      }, MOCK_DELAY);
    });
  },

  getBestSeller: async (): Promise<Seller> => {
    console.log(`Fetching best seller from artifacts/{appId}/public/data/milk_sellers`);
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(mockBestSeller);
      }, MOCK_DELAY);
    });
  }
};
