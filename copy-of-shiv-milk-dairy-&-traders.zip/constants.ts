import { Product, LocalizedString } from './types';

export const PHONE_NUMBER = "+919919747247";
export const ADDRESS = "BESIYA NIKAT SHIV MANDIR RAMNaGRA";

export const TRANSLATIONS = {
  header: {
    title: {
      en: "Shiv Milk Dairy & Traders",
      hi: "शिव मिल्क डेयरी एंड ट्रेडर्स"
    },
    greeting: {
      en: "🙏 Om Namah Shivay | Jai Mata Di 🙏",
      hi: "🙏 ओम नमः शिवाय | जय माता दी 🙏"
    },
    login: { en: "Member Login", hi: "सदस्य लॉगिन" },
    logout: { en: "Logout", hi: "लॉग आउट" },
    dashboard: { en: "Dashboard", hi: "डैशबोर्ड" }
  },
  hero: {
    welcome: { en: "Welcome to Shiv Milk Dairy", hi: "शिव मिल्क डेयरी में आपका स्वागत है" },
    subtitle: { 
      en: "Pure Milk, Quality Products, Trusted Service", 
      hi: "शुद्ध दूध, गुणवत्तापूर्ण उत्पाद, विश्वसनीय सेवा" 
    }
  },
  stats: {
    bestSeller: { en: "🏆 Best Seller Farmer", hi: "🏆 सर्वश्रेष्ठ विक्रेता किसान" },
    topFarmer: { en: "Top Farmer", hi: "शीर्ष किसान" },
    quantity: { en: "Total Quantity", hi: "कुल मात्रा" },
    liters: { en: "Ltr", hi: "ली." }
  },
  banners: {
    bulkTitle: { en: "📢 Bulk Orders & Pre-Booking", hi: "📢 थोक ऑर्डर और प्री-बुकिंग" },
    bulkDesc: { 
      en: "Special rates for Marriage, Parties, and Bulk Milk/Paneer orders. Pre-book to ensure availability!", 
      hi: "शादी, पार्टियों और थोक दूध/पनीर ऑर्डर के लिए विशेष दरें। उपलब्धता सुनिश्चित करने के लिए पहले से बुक करें!" 
    },
    preOrderBtn: { en: "Pre-Order Milk/Paneer", hi: "दूध/पनीर प्री-ऑर्डर करें" }
  },
  sections: {
    agro: { en: "Animal Nutrition & Agriculture", hi: "पशु पोषण और कृषि" },
    dairy: { en: "Dairy & Daily Essentials", hi: "डेयरी और दैनिक आवश्यकताएं" },
    health: { en: "Animal Health & Disease Control", hi: "पशु स्वास्थ्य और रोग नियंत्रण" },
    ai: { en: "Artificial Insemination (AI)", hi: "कृत्रिम गर्भाधान (AI)" }
  },
  products: {
    title: { en: "Our Products", hi: "हमारे उत्पाद" },
    orderNow: { en: "Order Now (WhatsApp)", hi: "अभी ऑर्डर करें (व्हाट्सएप)" },
    price: { en: "Price", hi: "मूल्य" },
    viewDetails: { en: "View Details", hi: "विवरण देखें" },
    close: { en: "Close", hi: "बंद करें" },
    selectOption: { en: "Select Option", hi: "विकल्प चुनें" }
  },
  dashboard: {
    title: { en: "Member Dashboard", hi: "सदस्य डैशबोर्ड" },
    memberId: { en: "Member ID", hi: "सदस्य आईडी" },
    earnings: { en: "Total Earnings", hi: "कुल कमाई" },
    lastCollection: { en: "Last Collection", hi: "अंतिम संग्रह" },
    loading: { en: "Loading...", hi: "लोड हो रहा है..." }
  },
  info: {
    collectionTimes: { en: "Milk Collection Times", hi: "दूध संग्रह का समय" },
    morning: { en: "Morning: 05:00 AM - 06:50 AM", hi: "सुबह: 05:00 AM - 06:50 AM" },
    evening: { en: "Evening: 05:00 PM - 07:00 PM", hi: "शाम: 05:00 PM - 07:00 PM" },
    contact: { en: "Contact Us", hi: "संपर्क करें" },
    vet: { en: "Veterinary & AI Services", hi: "पशु चिकित्सा और AI सेवाएं" },
    vetDesc: { 
      en: "Complete veterinary support including Artificial Insemination and Disease Control.", 
      hi: "कृत्रिम गर्भाधान और रोग नियंत्रण सहित पूर्ण पशु चिकित्सा सहायता।" 
    }
  },
  health: {
    desc: {
      en: "Expert consultation for Foot & Mouth Disease (FMD), Mastitis, and seasonal cattle diseases.",
      hi: "खुरपका-मुंहपका (FMD), थनेला और मौसमी पशु रोगों के लिए विशेषज्ञ परामर्श।"
    }
  },
  ai: {
    desc: {
      en: "High-quality Artificial Insemination services available under expert doctor supervision for breed improvement.",
      hi: "नस्ल सुधार के लिए विशेषज्ञ डॉक्टर की देखरेख में उच्च गुणवत्ता वाली कृत्रिम गर्भाधान सेवाएं उपलब्ध हैं।"
    }
  }
};

export const PRODUCTS: Product[] = [
  // --- AGRO & VET PRODUCTS ---
  {
    id: 'calcium-gold',
    category: 'agro',
    name: { en: "Shwetdhara Gold Calcium", hi: "श्वेतधारा गोल्ड कैल्शियम" },
    price: 150,
    variants: [
      { id: '1l', name: { en: "1 Litre", hi: "1 लीटर" }, price: 150 },
      { id: '5l', name: { en: "5 Litre", hi: "5 लीटर" }, price: 800 }
    ],
    description: { 
      en: "🌟 Boost Milk, Strengthen Health 🌟\n\nExperience the Real Milk Boost!\n\nProduct Description:\nShwetdhara Gold Calcium (Glycine Chelated) is a scientifically formulated supplement that helps increase milk production in livestock and improves their overall health.\n\nKey Benefits:\n💪 Strong Bones\n🔋 High Energy\n🥛 Increased Milk Yield\n✅ Supports Bone Health\n✅ Enhances Muscle Strength\n✅ Effective in Milk Production\n✅ Reduces Fatigue and Weakness\n\nNutrient-Rich:\nEnriched with 13+ essential nutrients: Calcium (Ca), Magnesium (Mg), Zinc (Zn), Iron (Fe), Vitamin A, D3, E. Suitable for all types of livestock – Cow, Buffalo, Goat.\n\nFor Farmers and Animals:\nHappy animals — Happy farmers — Double your income!\n🌾 Trust every drop of milk with Shwetdhara Gold!", 
      hi: "🌟 दूध बढ़ाएँ, स्वास्थ्य मजबूत करें 🌟\n\nअब आएगा असली दूध का धमाका!\n\nउत्पाद विवरण:\nश्वेतधारा गोल्ड कैल्शियम (Glycine Chelated) एक वैज्ञानिक रूप से तैयार किया गया सप्लीमेंट है, जो पशुओं में दूध उत्पादन बढ़ाने और उनकी समग्र सेहत सुधारने में मदद करता है।\n\nमुख्य लाभ:\n💪 ताकतवर हड्डियाँ\n🔋 ज़बरदस्त एनर्जी\n🥛 ज़्यादा दूध\n✅ हड्डियों को मजबूत बनाए\n✅ मांसपेशियों में ताकत बढ़ाए\n✅ दूध उत्पादन में असरदार\n✅ थकान और कमजोरी से राहत\n\nपोषक तत्वों से भरपूर:\n13+ आवश्यक पोषक तत्वों से समृद्ध: कैल्शियम (Ca), मैग्नीशियम (Mg), जिंक (Zn), आयरन (Fe), विटामिन A, D3, E। सभी प्रकार के पशुओं के लिए उपयुक्त – गाय, भैंस, बकरी।\n\nकिसान और पशु दोनों के लिए:\nपशु खुश — किसान खुश — आमदनी दोगुनी!\n🌾 हर बूंद में भरोसा — श्वेतधारा गोल्ड के साथ!" 
    },
    imageUrl: "https://picsum.photos/400/400?random=10"
  },
  {
    id: 'feed-50kg',
    category: 'agro',
    name: { en: "Shwetdhara Animal Feed (50kg)", hi: "श्वेतधारा पशु आहार (50 किग्रा)" },
    price: 1200, // Placeholder base price
    description: { 
      en: "🌾🐄 A Golden Opportunity for Farmers! 🐄🌾\nGet healthy livestock, more milk, and higher earnings with Shwetdhara Animal Feed!\nFor price, contact us.\n\n🟢 Shwetdhara Animal Feed – 50 kg Pack\n✔ Significant increase in milk production\n✔ Rich in energy, protein, and essential nutrients\n✔ BIS Certified – A Name You Can Trust\n\n🔹 Improved Breeding\n🔹 Healthy Calves\n🔹 High-Quality Milk\n\n🚜 Adopt Shwetdhara today – because only healthy animals make prosperous farmers!", 
      hi: "🌾🐄 किसानों के लिए सुनहरा मौका! 🐄🌾\nश्वेतधारा पशु आहार के साथ पाएं स्वस्थ पशु, ज़्यादा दूध और तगड़ी कमाई!\nमूल्य के लिए संपर्क करें।\n\n🟢 श्वेतधारा पशु आहार – 50 किलो पैक\n✔ दूध उत्पादन में उल्लेखनीय बढ़ोतरी\n✔ ऊर्जा, प्रोटीन और पोषक तत्वों से भरपूर\n✔ BIS प्रमाणित – भरोसे का नाम\n\n🔹 बेहतर प्रजनन\n🔹 स्वस्थ बछड़े\n🔹 उच्च गुणवत्ता वाला दूध\n\n🚜 आज ही अपनाएं श्वेतधारा – क्योंकि जब पशु होगा तंदुरुस्त, तभी किसान बनेगा समृद्ध!" 
    },
    imageUrl: "https://picsum.photos/400/400?random=11"
  },
  {
    id: 'min-mix',
    category: 'agro',
    name: { en: "Shwetdhara Min Chelated Mineral Mixture", hi: "श्वेतधारा मिन चिलेटेड मिनरल मिक्सचर" },
    price: 100,
    description: { 
      en: "🌿🐄 Region Special Chelated Mineral Mixture\n\n🧪 Optimal Nutrition, Increased Milk, Better Reproduction! 🐃🐐\n\nWith Regular Use:\n🔹 ✅ Increase in Milk Production\n🔹 ✅ Improvement in Reproductive Performance\n🔹 ✅ Overall Health Enhancement in Livestock\n🔹 ✅ Strong Bones and Muscles\n\n🧂 Key Ingredients (per 100 g):\nCalcium – 20 g\nPhosphorus – 10 g\nMagnesium – 1 g\nZinc, Iodine, Copper, Cobalt, Selenium, etc.\nVitamins A, D3, E\n\n📌 Animal Feed Supplement | Not for Human Consumption\n\n💰 ₹100 per kg (sometimes provided free with Shwetdhara Animal Feed – keep in touch)\n🌾 Healthy Animals, Higher Production, Prosperous Farmers!\n✅ ISO Certified Product\n🇮🇳 Developed with the joint collaboration of the Government of India and Government of Japan", 
      hi: "🌿🐄 क्षेत्र स्पेशल चिलेटेड मिनरल मिक्सचर\n\n🧪 उत्तम पोषण, ज़्यादा दूध, बेहतर प्रजनन! 🐃🐐\n\nनियमित प्रयोग से:\n🔹 ✅ दूध उत्पादन में बढ़ोतरी\n🔹 ✅ प्रजनन क्षमता में सुधार\n🔹 ✅ पशुओं की संपूर्ण सेहत में वृद्धि\n🔹 ✅ हड्डियाँ और मांसपेशियाँ होती हैं मज़बूत\n\n🧂 प्रमुख घटक (100 ग्राम में):\nकैल्शियम – 20 ग्राम\nफॉस्फोरस – 10 ग्राम\nमैग्नीशियम – 1 ग्राम\nजिंक, आयोडीन, कॉपर, कोबाल्ट, सेलेनियम आदि\nविटामिन A, D3, E\n\n📌 पशु आहार अनुपूरक | मानव उपयोग के लिए नहीं\n\n💰 ₹100 प्रति किलो (कभी-कभी श्वेतधारा पशु आहार के साथ मुफ्त – संपर्क में रहें)\n🌾 स्वस्थ पशु, ज़्यादा उत्पादन, किसान की तरक्की!\n✅ ISO प्रमाणित उत्पाद\n🇮🇳 भारत सरकार और जापान सरकार के संयुक्त सहयोग से विकसित" 
    },
    imageUrl: "https://picsum.photos/400/400?random=12"
  },
  {
    id: 'maize-seed',
    category: 'agro',
    name: { en: "Maize Seeds (Makka)", hi: "मक्का बीज" },
    price: 500,
    variants: [
      { id: 'dkc-9135', name: { en: "DKC 9135", hi: "DKC 9135" }, price: 500 },
      { id: 'dkc-9081', name: { en: "DKC 9081", hi: "DKC 9081" }, price: 700 }
    ],
    description: { 
      en: "Premium quality maize seeds for high yield fodder. Available in DKC 9081 and DKC 9135 varieties.", 
      hi: "अधिक उपज वाले चारे के लिए सर्वोत्तम गुणवत्ता वाले मक्का बीज। DKC 9081 और DKC 9135 किस्मों में उपलब्ध।" 
    },
    imageUrl: "https://picsum.photos/400/400?random=13"
  },
  {
    id: 'grass-chari',
    category: 'agro',
    name: { en: "Animal Grass/Chari Seeds", hi: "पशु चारा/चरी बीज" },
    price: 350,
    description: { 
      en: "High-yield green fodder seeds for all seasons.", 
      hi: "सभी मौसमों के लिए उच्च उपज वाले हरे चारे के बीज।" 
    },
    imageUrl: "https://picsum.photos/400/400?random=14"
  },
  {
    id: 'girawn',
    category: 'equipment',
    name: { en: "Girawn (Animal Husbandry)", hi: "गिरान (पशुपालन उत्पाद)" },
    price: 450,
    description: { 
      en: "Essential animal husbandry tools and accessories.", 
      hi: "आवश्यक पशुपालन उपकरण और सहायक उपकरण।" 
    },
    imageUrl: "https://picsum.photos/400/400?random=15"
  },

  // --- DAIRY & GROCERY ---
  {
    id: 'ghee',
    category: 'dairy',
    name: { en: "Pure Desi Ghee", hi: "शुद्ध देसी घी" },
    price: 650,
    description: { 
      en: "Homemade pure ghee made from fresh milk cream. Rich in aroma and taste.", 
      hi: "ताजी दूध की मलाई से बना घर का शुद्ध घी। सुगंध और स्वाद में भरपूर।" 
    },
    imageUrl: "https://picsum.photos/400/400?random=1"
  },
  {
    id: 'paneer',
    category: 'dairy',
    name: { en: "Fresh Paneer", hi: "ताज़ा पनीर" },
    price: 380,
    description: { 
      en: "Soft, fresh, and hygienic paneer. Perfect for Matar Paneer and other dishes. Bulk orders available.", 
      hi: "नरम, ताजा और स्वच्छ पनीर। मटर पनीर और अन्य व्यंजनों के लिए उत्तम। थोक ऑर्डर उपलब्ध।" 
    },
    imageUrl: "https://picsum.photos/400/400?random=20"
  },
  {
    id: 'dahi',
    category: 'dairy',
    name: { en: "Fresh Dahi (Curd)", hi: "ताज़ा दही" },
    price: 60,
    description: { 
      en: "Thick and creamy curd made from pure milk.", 
      hi: "शुद्ध दूध से बना गाढ़ा और मलाईदार दही।" 
    },
    imageUrl: "https://picsum.photos/400/400?random=21"
  },
  {
    id: 'matar',
    category: 'grocery',
    name: { en: "Green Peas (Matar)", hi: "हरी मटर" },
    price: 80,
    description: { 
      en: "Fresh frozen green peas.", 
      hi: "ताजी फ्रोजन हरी मटर।" 
    },
    imageUrl: "https://picsum.photos/400/400?random=22"
  }
];