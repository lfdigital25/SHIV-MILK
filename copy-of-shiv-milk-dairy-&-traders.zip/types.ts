export type Language = 'en' | 'hi';

export interface LocalizedString {
  en: string;
  hi: string;
}

export interface ProductVariant {
  id: string;
  name: LocalizedString;
  price: number;
}

export type ProductCategory = 'dairy' | 'agro' | 'grocery' | 'equipment';

export interface Product {
  id: string;
  category: ProductCategory;
  name: LocalizedString;
  price: number; // Base price
  description: LocalizedString;
  imageUrl: string;
  variants?: ProductVariant[]; // Optional variants (e.g., 1L vs 5L)
}

export interface UserStats {
  memberId: string;
  totalQuantity: number; // Liters
  totalEarnings: number; // INR
  lastCollectionDate: string;
  name: string;
}

export interface Seller {
  id: string;
  name: string;
  totalQuantity: number;
}