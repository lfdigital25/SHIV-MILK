import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  MapPin, 
  Award, 
  Stethoscope, 
  LogIn,
  Clock as ClockIcon,
  Truck,
  Syringe,
  Activity
} from 'lucide-react';
import { Language, Product, Seller } from './types';
import { TRANSLATIONS, PRODUCTS, ADDRESS, PHONE_NUMBER } from './constants';
import { authService, dbService } from './services/firebaseService';
import Clock from './components/Clock';
import ProductModal from './components/ProductModal';
import Dashboard from './components/Dashboard';

const App: React.FC = () => {
  const [language, setLanguage] = useState<Language>('hi');
  const [user, setUser] = useState<{ uid: string; email: string } | null>(null);
  const [showDashboard, setShowDashboard] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [bestSeller, setBestSeller] = useState<Seller | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const t = TRANSLATIONS;

  // Filter products by category
  const agroProducts = PRODUCTS.filter(p => p.category === 'agro' || p.category === 'equipment');
  const dairyProducts = PRODUCTS.filter(p => p.category === 'dairy' || p.category === 'grocery');

  // Initial Fetch for Best Seller
  useEffect(() => {
    dbService.getBestSeller().then(setBestSeller).catch(console.error);
  }, []);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const u = await authService.login();
      setUser(u);
      setShowDashboard(true);
    } catch (e) {
      console.error(e);
      alert("Login failed");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    await authService.logout();
    setUser(null);
    setShowDashboard(false);
  };

  const handlePreOrder = () => {
    const message = `Namaste, I am interested in Bulk Order / Pre-booking.`;
    const url = `https://wa.me/${PHONE_NUMBER.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
      {/* --- HEADER --- */}
      <header className="sticky top-0 z-40 bg-white shadow-md border-b border-green-100">
        <div className="bg-green-700 text-white text-xs py-1 px-4 text-center font-medium tracking-wide">
          {t.header.greeting[language]}
        </div>
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src="https://raw.githubusercontent.com/sb7863/shiv_milk_dairy/refs/heads/main/logo.png" 
              alt="Shiv Milk Dairy Logo" 
              className="h-12 w-12 md:h-16 md:w-16 object-contain rounded-full border-2 border-green-100 shadow-sm bg-white"
            />
            <div>
              <h1 className="text-lg md:text-xl font-bold text-green-800 leading-tight">
                {t.header.title[language]}
              </h1>
              <div className="text-xs text-green-600 hidden md:block">{ADDRESS}</div>
            </div>
          </div>

          <div className="flex items-center space-x-2 md:space-x-4">
            <button 
              onClick={() => setLanguage(prev => prev === 'en' ? 'hi' : 'en')}
              className="px-3 py-1 bg-green-50 text-green-700 text-sm font-semibold rounded-full hover:bg-green-100 transition"
            >
              {language === 'en' ? 'हिंदी' : 'English'}
            </button>
            
            {user ? (
              <button 
                onClick={() => setShowDashboard(true)}
                className="flex items-center space-x-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition shadow-sm"
              >
                <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
                <span className="hidden sm:inline">{t.header.dashboard[language]}</span>
                <span className="sm:hidden">Profile</span>
              </button>
            ) : (
              <button 
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="flex items-center space-x-2 bg-slate-800 text-white px-4 py-2 rounded-lg hover:bg-slate-700 transition"
              >
                {isLoggingIn ? (
                  <span className="text-xs">...</span>
                ) : (
                  <>
                    <LogIn size={16} />
                    <span className="hidden sm:inline">{t.header.login[language]}</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </header>

      {/* --- HERO SECTION --- */}
      <div className="bg-gradient-to-br from-green-50 to-yellow-50 py-8 md:py-12 px-4 text-center border-b border-yellow-100">
        <div className="container mx-auto">
          <div className="flex justify-center mb-6">
            <Clock />
          </div>
          <h2 className="text-3xl md:text-5xl font-extrabold text-green-800 mb-4 drop-shadow-sm">
            {t.hero.welcome[language]}
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto font-medium mb-8">
            {t.hero.subtitle[language]}
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8 space-y-12">
        
        {/* --- BULK ORDER / PRE-ORDER BANNER --- */}
        <section className="bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-6 md:p-8 shadow-xl text-white transform hover:scale-[1.01] transition-transform">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-6 md:mb-0 md:mr-6">
              <div className="flex items-center space-x-3 mb-2">
                <Truck className="text-yellow-300" size={32} />
                <h3 className="text-2xl font-bold">{t.banners.bulkTitle[language]}</h3>
              </div>
              <p className="text-green-50 text-lg opacity-90 max-w-xl">
                {t.banners.bulkDesc[language]}
              </p>
            </div>
            <button 
              onClick={handlePreOrder}
              className="bg-yellow-400 text-green-900 px-8 py-3 rounded-xl font-bold hover:bg-yellow-300 transition shadow-lg whitespace-nowrap"
            >
              {t.banners.preOrderBtn[language]}
            </button>
          </div>
        </section>

        {/* --- BEST SELLER FARMER --- */}
        {bestSeller && (
          <section className="bg-white rounded-2xl p-6 shadow-lg border border-yellow-200">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="flex items-center space-x-4 mb-4 md:mb-0">
                <div className="bg-yellow-100 p-4 rounded-full">
                  <Award className="text-yellow-600 w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800">{t.stats.bestSeller[language]}</h3>
                  <p className="text-green-600 font-medium">{t.stats.topFarmer[language]}</p>
                </div>
              </div>
              <div className="text-center md:text-right bg-green-50 px-6 py-3 rounded-xl w-full md:w-auto">
                <p className="text-sm text-gray-500 uppercase tracking-wide">{t.stats.quantity[language]}</p>
                <p className="text-3xl font-black text-green-700">
                  {bestSeller.totalQuantity} <span className="text-lg text-green-500">{t.stats.liters[language]}</span>
                </p>
                <p className="text-sm font-semibold text-gray-700 mt-1">{bestSeller.name}</p>
              </div>
            </div>
          </section>
        )}

        {/* --- PRODUCTS SECTION 1: AGRO & VET --- */}
        <section>
          <div className="flex items-center space-x-3 mb-8">
            <div className="h-8 w-1 bg-green-500 rounded-full"></div>
            <h3 className="text-2xl font-bold text-gray-800">{t.sections.agro[language]}</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {agroProducts.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                language={language} 
                onClick={() => setSelectedProduct(product)} 
              />
            ))}
          </div>
        </section>

        {/* --- PRODUCTS SECTION 2: DAIRY & GROCERY --- */}
        <section>
          <div className="flex items-center space-x-3 mb-8">
            <div className="h-8 w-1 bg-yellow-400 rounded-full"></div>
            <h3 className="text-2xl font-bold text-gray-800">{t.sections.dairy[language]}</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {dairyProducts.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                language={language} 
                onClick={() => setSelectedProduct(product)} 
              />
            ))}
          </div>
        </section>

        {/* --- SERVICES & INFO --- */}
        <section className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Collection Times */}
          <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100 flex flex-col">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-blue-100 p-2 rounded-full">
                <ClockIcon className="text-blue-600" size={24} />
              </div>
              <h4 className="text-lg font-bold text-blue-900">{t.info.collectionTimes[language]}</h4>
            </div>
            <div className="space-y-3 flex-1">
              <div className="bg-white p-3 rounded-xl shadow-sm border border-blue-50">
                <span className="block font-medium text-gray-600 text-sm mb-1">{t.info.morning[language].split(':')[0]}</span>
                <span className="block font-bold text-blue-600 text-lg">{t.info.morning[language].split(': ').slice(1).join(': ')}</span>
              </div>
              <div className="bg-white p-3 rounded-xl shadow-sm border border-blue-50">
                <span className="block font-medium text-gray-600 text-sm mb-1">{t.info.evening[language].split(':')[0]}</span>
                <span className="block font-bold text-blue-600 text-lg">{t.info.evening[language].split(': ').slice(1).join(': ')}</span>
              </div>
            </div>
          </div>

          {/* Veterinary & AI */}
          <div className="bg-purple-50 rounded-2xl p-6 border border-purple-100 flex flex-col">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-purple-100 p-2 rounded-full">
                <Syringe className="text-purple-600" size={24} />
              </div>
              <h4 className="text-lg font-bold text-purple-900">{t.info.vet[language]}</h4>
            </div>
            <div className="space-y-4 flex-1">
               <div className="bg-white/60 p-3 rounded-lg">
                 <h5 className="font-bold text-purple-800 text-sm mb-1">{t.sections.ai[language]}</h5>
                 <p className="text-sm text-purple-900/80">{t.ai.desc[language]}</p>
               </div>
               <button onClick={() => window.open(`tel:${PHONE_NUMBER}`)} className="w-full flex items-center justify-center space-x-2 bg-purple-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-purple-700 transition">
                 <Phone size={16} />
                 <span>{t.info.contact[language]}</span>
               </button>
            </div>
          </div>

          {/* Health & Disease */}
          <div className="bg-rose-50 rounded-2xl p-6 border border-rose-100 flex flex-col md:col-span-2 lg:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-rose-100 p-2 rounded-full">
                <Activity className="text-rose-600" size={24} />
              </div>
              <h4 className="text-lg font-bold text-rose-900">{t.sections.health[language]}</h4>
            </div>
            <p className="text-rose-900/80 mb-4 flex-1">
              {t.health.desc[language]}
            </p>
            <div className="bg-white/60 p-4 rounded-xl text-center">
              <p className="font-bold text-rose-700">{PHONE_NUMBER}</p>
            </div>
          </div>
        </section>

      </main>

      {/* --- FOOTER --- */}
      <footer className="bg-slate-900 text-slate-300 py-12 mt-12">
        <div className="container mx-auto px-4 text-center md:text-left grid md:grid-cols-3 gap-8">
          <div>
            <h5 className="text-white font-bold text-lg mb-4">{t.header.title[language]}</h5>
            <p className="text-sm leading-relaxed max-w-xs mx-auto md:mx-0">
              {t.hero.subtitle[language]}
            </p>
          </div>
          <div>
            <h5 className="text-white font-bold text-lg mb-4">{t.info.contact[language]}</h5>
            <div className="flex flex-col items-center md:items-start space-y-2">
              <div className="flex items-center space-x-2">
                <Phone size={16} />
                <span>{PHONE_NUMBER}</span>
              </div>
              <div className="flex items-start space-x-2 text-left">
                <MapPin size={16} className="mt-1 flex-shrink-0" />
                <span>{ADDRESS}</span>
              </div>
            </div>
          </div>
          <div className="text-center md:text-right pt-4 md:pt-0">
            <p className="text-xs text-slate-500">
              © {new Date().getFullYear()} Shiv Milk Dairy. All rights reserved.
            </p>
            <div className="mt-2 text-xs text-slate-600">
              Jai Mata Di | Om Namah Shivay
            </div>
          </div>
        </div>
      </footer>

      {/* --- MODALS --- */}
      {showDashboard && user && (
        <Dashboard 
          user={user} 
          language={language} 
          onClose={() => setShowDashboard(false)}
          onLogout={handleLogout}
        />
      )}

      {selectedProduct && (
        <ProductModal 
          product={selectedProduct} 
          language={language}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
};

// --- SUB COMPONENTS ---

const ProductCard: React.FC<{ product: Product; language: Language; onClick: () => void }> = ({ product, language, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all cursor-pointer group border border-slate-100 flex flex-col h-full"
    >
      <div className="h-48 overflow-hidden relative">
        <img 
          src={product.imageUrl} 
          alt={product.name[language]}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {product.variants && (
          <div className="absolute bottom-2 right-2 bg-black/50 backdrop-blur-sm text-white text-[10px] px-2 py-1 rounded-full">
            {product.variants.length} Options
          </div>
        )}
      </div>
      <div className="p-4 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-2">
          <h4 className="font-bold text-lg text-gray-800 line-clamp-2 leading-snug">
            {product.name[language]}
          </h4>
          <span className="bg-green-100 text-green-800 text-xs font-bold px-2 py-1 rounded whitespace-nowrap ml-2">
            ₹{product.price}{product.variants ? '+' : ''}
          </span>
        </div>
        <p className="text-sm text-gray-500 line-clamp-2 mb-4 flex-1 whitespace-pre-line">
          {product.description[language]}
        </p>
        <button className="w-full bg-slate-50 text-green-700 font-semibold py-2 rounded-lg border border-green-200 group-hover:bg-green-600 group-hover:text-white transition-colors">
          {TRANSLATIONS.products.viewDetails[language]}
        </button>
      </div>
    </div>
  );
};

export default App;