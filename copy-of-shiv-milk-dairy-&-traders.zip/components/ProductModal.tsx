import React, { useState, useEffect } from 'react';
import { X, MessageCircle, Check } from 'lucide-react';
import { Product, Language, ProductVariant } from '../types';
import { TRANSLATIONS, PHONE_NUMBER } from '../constants';

interface ProductModalProps {
  product: Product;
  language: Language;
  onClose: () => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ product, language, onClose }) => {
  const t = TRANSLATIONS.products;
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);

  // Initialize selected variant if product has variants
  useEffect(() => {
    if (product.variants && product.variants.length > 0) {
      setSelectedVariant(product.variants[0]);
    } else {
      setSelectedVariant(null);
    }
  }, [product]);

  const currentPrice = selectedVariant ? selectedVariant.price : product.price;

  const handleWhatsAppOrder = () => {
    let message = `Namaste, I want to order *${product.name.en}*.`;
    
    if (selectedVariant) {
      message += `\nOption: ${selectedVariant.name.en}`;
      message += `\nPrice: ₹${selectedVariant.price}`;
    } else {
      message += `\nPrice: ₹${product.price}`;
    }

    const url = `https://wa.me/${PHONE_NUMBER.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-fadeIn max-h-[90vh] flex flex-col">
        {/* Header Image */}
        <div className="relative h-56 flex-shrink-0">
          <img 
            src={product.imageUrl} 
            alt={product.name[language]} 
            className="w-full h-full object-cover"
          />
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-white/80 p-2 rounded-full hover:bg-white transition-colors shadow-lg"
          >
            <X size={24} className="text-gray-800" />
          </button>
        </div>
        
        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-2xl font-bold text-gray-900 leading-tight">
              {product.name[language]}
            </h3>
            <div className="text-right">
              <p className="text-3xl font-bold text-green-600">
                ₹{currentPrice}
              </p>
              {product.variants && <span className="text-xs text-gray-500">per unit/pack</span>}
            </div>
          </div>

          {/* Variant Selection */}
          {product.variants && (
            <div className="mb-6">
              <p className="text-sm font-semibold text-gray-700 mb-2">{t.selectOption[language]}</p>
              <div className="grid grid-cols-2 gap-3">
                {product.variants.map((variant) => (
                  <button
                    key={variant.id}
                    onClick={() => setSelectedVariant(variant)}
                    className={`px-4 py-3 rounded-lg border-2 text-left transition-all ${
                      selectedVariant?.id === variant.id 
                        ? 'border-green-500 bg-green-50 text-green-800' 
                        : 'border-gray-200 hover:border-green-200'
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-bold">{variant.name[language]}</span>
                      {selectedVariant?.id === variant.id && <Check size={16} className="text-green-600" />}
                    </div>
                    <span className="text-sm text-gray-600">₹{variant.price}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
          
          <div className="bg-green-50 p-4 rounded-xl mb-6">
            <p className="text-gray-700 leading-relaxed whitespace-pre-line text-sm md:text-base">
              {product.description[language]}
            </p>
          </div>
        </div>

        {/* Footer Action */}
        <div className="p-4 border-t border-gray-100 bg-white">
          <button
            onClick={handleWhatsAppOrder}
            className="w-full flex items-center justify-center space-x-2 bg-green-600 hover:bg-green-700 text-white py-4 rounded-xl font-bold text-lg transition-transform active:scale-95 shadow-lg shadow-green-200"
          >
            <MessageCircle size={24} />
            <span>{t.orderNow[language]}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;