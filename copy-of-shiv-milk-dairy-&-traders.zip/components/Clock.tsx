import React, { useState, useEffect } from 'react';
import { Clock as ClockIcon } from 'lucide-react';

const Clock: React.FC = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour12: true,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div className="flex items-center space-x-2 text-green-800 bg-green-100 px-4 py-2 rounded-full shadow-sm">
      <ClockIcon size={18} />
      <div className="flex flex-col sm:flex-row sm:space-x-2 text-sm font-semibold">
        <span>{formatTime(time)}</span>
        <span className="hidden sm:inline">|</span>
        <span>{formatDate(time)}</span>
      </div>
    </div>
  );
};

export default Clock;
