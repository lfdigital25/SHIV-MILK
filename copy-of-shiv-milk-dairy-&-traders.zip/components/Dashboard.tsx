import React, { useEffect, useState } from 'react';
import { X, User, Droplet, Wallet, Calendar } from 'lucide-react';
import { UserStats, Language } from '../types';
import { TRANSLATIONS } from '../constants';
import { dbService, authService } from '../services/firebaseService';

interface DashboardProps {
  user: { uid: string; email: string };
  language: Language;
  onClose: () => void;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, language, onClose, onLogout }) => {
  const [stats, setStats] = useState<UserStats | null>(null);
  const [loading, setLoading] = useState(true);
  const t = TRANSLATIONS.dashboard;

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await dbService.getUserStats(user.uid);
        setStats(data);
      } catch (error) {
        console.error("Failed to fetch stats", error);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, [user.uid]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-green-600 p-6 flex justify-between items-center text-white">
          <div className="flex items-center space-x-3">
            <div className="bg-white/20 p-2 rounded-full">
              <User size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold">{t.title[language]}</h2>
              <p className="text-green-100 text-sm">{user.email}</p>
            </div>
          </div>
          <button onClick={onClose} className="hover:bg-white/20 p-2 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1">
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-600"></div>
            </div>
          ) : stats ? (
            <div className="grid gap-4">
              <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100 flex items-center space-x-4">
                <div className="bg-yellow-100 p-3 rounded-full text-yellow-600">
                  <User size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-500">{t.memberId[language]}</p>
                  <p className="text-lg font-bold text-gray-800">{stats.memberId}</p>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 flex items-center space-x-4">
                <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                  <Droplet size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-500">{TRANSLATIONS.stats.quantity[language]}</p>
                  <p className="text-xl font-bold text-gray-800">{stats.totalQuantity} {TRANSLATIONS.stats.liters[language]}</p>
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-xl border border-green-100 flex items-center space-x-4">
                <div className="bg-green-100 p-3 rounded-full text-green-600">
                  <Wallet size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-500">{t.earnings[language]}</p>
                  <p className="text-xl font-bold text-gray-800">₹{stats.totalEarnings.toLocaleString('en-IN')}</p>
                </div>
              </div>

              <div className="bg-purple-50 p-4 rounded-xl border border-purple-100 flex items-center space-x-4">
                <div className="bg-purple-100 p-3 rounded-full text-purple-600">
                  <Calendar size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-500">{t.lastCollection[language]}</p>
                  <p className="text-lg font-bold text-gray-800">{stats.lastCollectionDate}</p>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-center text-gray-500">No data found.</p>
          )}

          <button
            onClick={onLogout}
            className="mt-8 w-full py-3 border-2 border-red-500 text-red-500 font-semibold rounded-xl hover:bg-red-50 transition-colors"
          >
            {TRANSLATIONS.header.logout[language]}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
